print ("hello friends")

a = 5
b = 2
c = a + b

print (c)

