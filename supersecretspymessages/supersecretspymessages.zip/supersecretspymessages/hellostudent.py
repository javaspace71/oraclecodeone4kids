print("hello student!")
print("Welcome to Python programming")
a = 20
b = 3
print(a * b)
print(a % b)
msg = "hello there! "
multimsg = msg * 3
print(multimsg)